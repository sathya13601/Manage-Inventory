package com.assignment.manage.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManageInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManageInventoryApplication.class, args);
	}

}
